"use strict"


document.addEventListener('DOMContentLoaded', function () {
	// const form = document.getElementById('form');
	// const subForm = document.getElementById('subform');
	// form.addEventListener('submit', formSend);

	const forms = document.querySelectorAll('form[id*="form"]'); //получаем все формы
	console.log(forms);
	for (let index = 0; index < forms.length; index++) {
		const curentForm = forms[index];
		curentForm.addEventListener('submit', async function (e) {
			if (curentForm.id === 'form-question') {
				e.preventDefault();
				let error = formValidate(curentForm);
				let formData = new FormData(curentForm);

				if (error === 0) {
					curentForm.classList.add('_sending');

					let response = await fetch('sendquestion.php', {
						method: 'POST',
						body: formData
					});
					if (response.ok) {
						let result = await response.json();
						alert(result.message);
						// formPreview.inheritHTML = '';
						curentForm.reset();
						curentForm.classList.remove('_sending');
					} else {
						alert("Ошибка");
						curentForm.classList.remove('_sending');
					}
				} else {
					alert('Заполните обязательные поля!*');
				}
			} else {
				e.preventDefault();
				let error = formValidate(curentForm);
				let formData = new FormData(curentForm);
				if (error === 0) {
					curentForm.classList.add('_sending');

					let response = await fetch('sendorder.php', {
						method: 'POST',
						body: formData
					});
					if (response.ok) {
						let result = await response.json();
						alert(result.message);
						// formPreview.inheritHTML = '';
						curentForm.reset();
						curentForm.classList.remove('_sending');
					} else {
						alert("Ошибка");
						curentForm.classList.remove('_sending');
					}
				} else {
					alert('Заполните обязательные поля!*');
				}
			}
		})

	}

	function formValidate(form) {
		let error = 0;
		let curentFormClass = form.getAttribute('class');
		// console.log(curentFormClass);
		let formReq = form.querySelectorAll('._req');
		// console.log(formReq);

		for (let index = 0; index < formReq.length; index++) {
			const input = formReq[index];
			formRemoveError(input);

			if (input.classList.contains('_email')) {
				if (emailTest(input)) {
					formAddError(input);
					error++;
				}
			} else if (input.classList.contains('_tel')) {
				if (telephoneTest(input)) {
					formAddError(input);
					error++;
				}

			} else if (input.getAttribute("type") === "checkbox" && input.checked === false) {
				formAddError(input);
				error++;

			} else {
				if (input.value === '') {
					formAddError(input);
					error++;
				}
			}

		}
		return error;
	}

	function formAddError(input) {
		input.parentElement.classList.add('_error');
		input.classList.add('_error');
	}

	function formRemoveError(input) {
		input.parentElement.classList.remove('_error');
		input.classList.remove('_error');
	}

	//Функция проверки E-mail

	function emailTest(input) {
		return !/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,8})+$/.test(input.value);
	}
	function telephoneTest(input) {
		return !/^(([\+][0-9]{1,3})|[0-9])[0-9]{10,13}$/.test(input.value);
	}
});
