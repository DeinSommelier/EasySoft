"use strict"


document.addEventListener('DOMContentLoaded', function () {
	let burger = document.getElementsByClassName('header__burger');
	console.log(burger);
	for (let index = 0; index < burger.length; index++) {
		burger[index].addEventListener('click', function () {
			let headMenu = document.getElementsByClassName('header-menu');
			for (let index = 0; index < headMenu.length; index++) {
				headMenu[index].classList.toggle('active');
			}
			burger[index].classList.toggle('active');
			document.querySelector('body').classList.toggle('lock');
		});
	}
});
