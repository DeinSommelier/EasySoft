let anchors = document.querySelectorAll('a[href^="#"]').forEach(link => {
	link.addEventListener('click', function (e) {
		e.preventDefault();

		let href = this.getAttribute('href').substring(1);

		const scrollTarget = document.getElementById(href);

		const topOffset = document.querySelector('.header').offsetHeight;
		//const topOffset = 0;

		const elementPosition = scrollTarget.getBoundingClientRect().top;
		const offsetPosition = elementPosition - topOffset;

		window.scrollBy({
			top: offsetPosition,
			behavior: 'smooth'
		});
	});
});
// for (let index = 0; index < anchors.length; index++) {
// 	anchors[index].addEventListener("click", function (e) {
// 		e.preventDefault();
// 		let blockID = anchors[index].getAttribute('href');
// 		document.querySelector('' + blockID).scrollIntoView({
// 			behavior: "smooth",
// 			block: "start"
// 		});
// 	});
// }

// function scrollTo(element) {
// 	window.scroll({
// 		left: 0,
// 		top: element.offsetTop,
// 		behavior: "smooth"
// 	})
// }

// let links = document.querySelectorAll('*.__link');

// for (let index = 0; index < links.length; index++) {
// 	links[index].button.addEventListener('click', () => {
// 		console.log('done');
// 	})
// }
// // button.addEventListener('click', () => {
// // 	console.log('done');
// // })

// "use strict"

// document.addEventListener('DOMContentLoaded', function () {
// 	//window.scrollTo()
// 	let scrolled;
// 	let timer;

// 	document.get

// });